// Importa los módulos necesarios
const express = require("express");
const nodemailer = require("nodemailer");
const crypto = require("crypto");
const dotenv = require("dotenv");
const cors = require("cors");  // Importa CORS

dotenv.config();  // Cargar variables de entorno desde el archivo .env

const app = express();
const port = process.env.PORT || 3000;  // Usar el puerto desde .env o 3000 por defecto

app.use(express.json()); // Para que Express pueda parsear las solicitudes JSON

// Configura CORS
app.use(cors());  // Esto habilita CORS para todas las solicitudes entrantes

// Configuración de Nodemailer
const transporter = nodemailer.createTransport({
  service: "gmail",
  auth: {
    user: process.env.GMAIL_USER,
    pass: process.env.GMAIL_PASS,
  },
});

// Base de datos simulada en memoria
let usuarios = [];

// Ruta para registrar un usuario
app.post("/registro", (req, res) => {
  const { nombre, correo, contrasena } = req.body;

  // Verificar si el correo ya está registrado
  if (usuarios.find((user) => user.correo === correo)) {
    return res.status(400).json({ message: "El correo ya está registrado" });
  }

  // Generar un código de verificación único
  const codigoVerificacion = crypto.randomBytes(3).toString("hex");

  // Guardar al usuario
  usuarios.push({
    nombre,
    correo,
    contrasena,
    codigoVerificacion,
    verificado: false,
  });

  // Configurar el correo de verificación
  const mailOptions = {
    from: process.env.GMAIL_USER,
    to: correo,
    subject: "Verificación de cuenta - Relaxify",
    text: `Gracias por registrarte en Relaxify. Tu código de verificación es: ${codigoVerificacion}`,
  };

  // Enviar el correo
  transporter.sendMail(mailOptions, (error, info) => {
    if (error) {
      console.error("Error al enviar el correo:", error);
      return res.status(500).json({ message: "Error al enviar el correo" });
    }
    console.log("Correo enviado:", info.response);
    return res.status(200).json({ message: "Te hemos enviado un correo con el código de verificación" });
  });
});

// Ruta para verificar el código
app.post("/verificar", (req, res) => {
  const { correo, codigo } = req.body;

  const usuario = usuarios.find((user) => user.correo === correo);
  
  if (!usuario) {
    return res.status(404).json({ message: "Usuario no encontrado" });
  }

  if (usuario.codigoVerificacion === codigo) {
    usuario.verificado = true;
    return res.status(200).json({ message: "Cuenta verificada con éxito" });
  }

  return res.status(400).json({ message: "Código incorrecto" });
});

// Iniciar el servidor
app.listen(port, () => {
  console.log(`Servidor corriendo en http://localhost:${port}`);
});
